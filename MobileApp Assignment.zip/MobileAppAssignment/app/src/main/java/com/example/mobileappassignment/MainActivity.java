package com.example.mobileappassignment;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText input1, input2, trigInput;
    private Switch switchDegreesRadians;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input1 = findViewById(R.id.input1);
        input2 = findViewById(R.id.input2);
        trigInput = findViewById(R.id.trig_input);
        switchDegreesRadians = findViewById(R.id.switch_degrees_radians);

        // Arithmetic buttons setup
        Button addButton = findViewById(R.id.add_button);
        Button subtractButton = findViewById(R.id.subtract_button);
        Button multiplyButton = findViewById(R.id.multiply_button);
        Button divideButton = findViewById(R.id.divide_button);

        // Trigonometric buttons setup
        Button sineButton = findViewById(R.id.sine_button);
        Button cosineButton = findViewById(R.id.cosine_button);
        Button tangentButton = findViewById(R.id.tangent_button);
        Button inverseSineButton = findViewById(R.id.inverse_sine_button);
        Button inverseCosineButton = findViewById(R.id.inverse_cosine_button);
        Button inverseTangentButton = findViewById(R.id.inverse_tangent_button);
        Button reciprocalSineButton = findViewById(R.id.reciprocal_sine_button);
        Button reciprocalCosineButton = findViewById(R.id.reciprocal_cosine_button);
        Button reciprocalTangentButton = findViewById(R.id.reciprocal_tangent_button);
        Button inverseReciprocalSineButton = findViewById(R.id.inverse_reciprocal_sine_button);
        Button inverseReciprocalCosineButton = findViewById(R.id.inverse_reciprocal_cosine_button);
        Button inverseReciprocalTangentButton = findViewById(R.id.inverse_reciprocal_tangent_button);

        // Set click listeners for arithmetic buttons
        addButton.setOnClickListener(v -> calculateAddition());
        subtractButton.setOnClickListener(v -> calculateSubtraction());
        multiplyButton.setOnClickListener(v -> calculateMultiplication());
        divideButton.setOnClickListener(v -> calculateDivision());

        // Set click listeners for trigonometric buttons
        sineButton.setOnClickListener(v -> calculateSine());
        cosineButton.setOnClickListener(v -> calculateCosine());
        tangentButton.setOnClickListener(v -> calculateTangent());
        inverseSineButton.setOnClickListener(v -> calculateInverseSine());
        inverseCosineButton.setOnClickListener(v -> calculateInverseCosine());
        inverseTangentButton.setOnClickListener(v -> calculateInverseTangent());
        reciprocalSineButton.setOnClickListener(v -> calculateReciprocalSine());
        reciprocalCosineButton.setOnClickListener(v -> calculateReciprocalCosine());
        reciprocalTangentButton.setOnClickListener(v -> calculateReciprocalTangent());
        inverseReciprocalSineButton.setOnClickListener(v -> calculateInverseReciprocalSine());
        inverseReciprocalCosineButton.setOnClickListener(v -> calculateInverseReciprocalCosine());
        inverseReciprocalTangentButton.setOnClickListener(v -> calculateInverseReciprocalTangent());
    }

    // Arithmetic Operations
    private void calculateAddition() {
        double num1 = getInputValue(input1);
        double num2 = getInputValue(input2);
        double result = num1 + num2;
        showToast("Result: " + result);
    }
    private void calculateSubtraction() {
        double num1 = getInputValue(input1);
        double num2 = getInputValue(input2);
        double result = num1 - num2;
        showToast("Result: " + result);
    }

    private void calculateMultiplication() {
        double num1 = getInputValue(input1);
        double num2 = getInputValue(input2);
        double result = num1 * num2;
        showToast("Result: " + result);
    }

    private void calculateDivision() {
        double num1 = getInputValue(input1);
        double num2 = getInputValue(input2);
        if (num2 == 0) {
            showErrorDialog("Cannot divide by zero.");
            return;
        }
        double result = num1 / num2;
        showToast("Result: " + result);
    }

    // Trigonometric Operations
    private void calculateSine() {
        double angle = getAngleInRadians();
        double result = Math.sin(angle);
        showToast("Sine: " + result);
    }

    private void calculateCosine() {
        double angle = getAngleInRadians();
        double result = Math.cos(angle);
        showToast("Cosine: " + result);
    }

    private void calculateTangent() {
        double angle = getAngleInRadians();
        double result = Math.tan(angle);
        showToast("Tangent: " + result);
    }

    private void calculateInverseSine() {
        try {
            double value = Double.parseDouble(trigInput.getText().toString());
            double result = Math.asin(value); // Result is in radians
            showToast("Inverse Sine: " + Math.toDegrees(result));
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateInverseCosine() {
        try {
            double value = Double.parseDouble(trigInput.getText().toString());
            double result = Math.acos(value); // Result is in radians
            showToast("Inverse Cosine: " + Math.toDegrees(result));
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateInverseTangent() {
        try {
            double value = Double.parseDouble(trigInput.getText().toString());
            double result = Math.atan(value); // Result is in radians
            showToast("Inverse Tangent: " + Math.toDegrees(result));
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateReciprocalSine() {
        try {
            double angle = getAngleInRadians();
            if (Math.sin(angle) == 0) {
                showErrorDialog("Undefined value (division by zero).");
                return;
            }
            double result = 1 / Math.sin(angle);
            showToast("Reciprocal Sine: " + result);
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateReciprocalCosine() {
        try {
            double angle = getAngleInRadians();
            if (Math.cos(angle) == 0) {
                showErrorDialog("Undefined value (division by zero).");
                return;
            }
            double result = 1 / Math.cos(angle);
            showToast("Reciprocal Cosine: " + result);
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateReciprocalTangent() {
        try {
            double angle = getAngleInRadians();
            if (Math.tan(angle) == 0) {
                showErrorDialog("Undefined value (division by zero).");
                return;
            }
            double result = 1 / Math.tan(angle);
            showToast("Reciprocal Tangent: " + result);
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateInverseReciprocalSine() {
        try {
            double value = Double.parseDouble(trigInput.getText().toString());
            if (value == 0) {
                showErrorDialog("Undefined value (division by zero).");
                return;
            }
            double result = Math.asin(1 / value); // Result is in radians
            showToast("Inverse Reciprocal Sine: " + Math.toDegrees(result));
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateInverseReciprocalCosine() {
        try {
            double value = Double.parseDouble(trigInput.getText().toString());
            if (value == 0) {
                showErrorDialog("Undefined value (division by zero).");
                return;
            }
            double result = Math.acos(1 / value); // Result is in radians
            showToast("Inverse Reciprocal Cosine: " + Math.toDegrees(result));
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    private void calculateInverseReciprocalTangent() {
        try {
            double value = Double.parseDouble(trigInput.getText().toString());
            if (value == 0) {
                showErrorDialog("Undefined value (division by zero).");
                return;
            }
            double result = Math.atan(1 / value); // Result is in radians
            showToast("Inverse Reciprocal Tangent: " + Math.toDegrees(result));
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
        }
    }

    // Helper Methods
    private double getInputValue(EditText editText) {
        try {
            return Double.parseDouble(editText.getText().toString());
        } catch (NumberFormatException e) {
            showErrorDialog("Invalid input. Please enter a valid number.");
            return 0; // Default to 0 if invalid input
        }
    }

    private double getAngleInRadians() {
        double angle = Double.parseDouble(trigInput.getText().toString());
        return switchDegreesRadians.isChecked() ? Math.toRadians(angle) : angle;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}
