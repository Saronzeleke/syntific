Name:Saron Zeleke;
ID:1402302;

Description:
            Scientific Calculator

            This is a scientific calculator that can perform a variety of arithmetic and trigonometric operations. It has a user-friendly interface that allows you to easily enter numbers and select operations. The calculator also includes a number of features that make it more powerful and versatile, such as:

            Arithmetic operations: Addition, subtraction, multiplication, division, and modulus.
            Trigonometric operations: Sine, cosine, tangent, inverse sine (arcsine), inverse cosine (arccosine), and inverse tangent (arctangent).
            Reciprocal trigonometric functions: Cosecant (csc), secant (sec), and cotangent (cot).
            Inverse reciprocal trigonometric functions: Arcscsc (csc^-1), arcsec (sec^-1), and arccot (cot^-1).
            Degrees or radians mode: You can switch between degrees and radians mode using the switch at the top of the calculator.
            Using the Calculator

            Enter the first number in the first input field.
            Select the operation you want to perform using the buttons in the middle of the screen.
            Enter the second number in the second input field (if applicable).
            Tap the equals button (=) to see the result.
            The result will be displayed in the text field at the bottom of the screen.

            Example

            To calculate the sine of 30 degrees, you would follow these steps:

            Enter 30 in the first input field.
            Tap the sine button (sin).
            Make sure the degrees mode is selected (indicated by the switch being on).
            Additional Features

            The calculator can handle both positive and negative numbers.
            The calculator can display numbers in scientific notation.
                                 THANK YOU !